require('require-dir')('./gulp');

require('gulp').task('default', ['test', 'build']);
