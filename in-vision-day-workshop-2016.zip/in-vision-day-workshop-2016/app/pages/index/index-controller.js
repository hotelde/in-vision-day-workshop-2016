module.exports = function IndexPageCtrl () {
  
}
