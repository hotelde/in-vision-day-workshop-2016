module.exports = function NotFoundCtrl ( ){

}
