module.exports = function MenuCtrl () {
  
}
